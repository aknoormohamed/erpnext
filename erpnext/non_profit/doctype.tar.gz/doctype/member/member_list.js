frappe.listview_settings['Member'] = {
	add_fields: ["member_name", "membership_type", "image"],
};
