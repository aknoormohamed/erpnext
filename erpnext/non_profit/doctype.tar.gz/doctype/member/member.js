// Copyright (c) 2017, Frappe Technologies Pvt. Ltd. and contributors
// For license information, please see license.txt

frappe.ui.form.on('Member', {
    refresh: function(frm) {

        frappe.dynamic_link = { doc: frm.doc, fieldname: 'name', doctype: 'Member' };

        frm.toggle_display(['address_html', 'contact_html'], !frm.doc.__islocal);

        if (!frm.doc.__islocal) {
            frappe.contacts.render_address_and_contact(frm);

            // custom buttons
            // frm.add_custom_button(__('Accounting Ledger'), function() {
            //  frappe.set_route('query-report', 'General Ledger',
            //      {party_type:'Member', party:frm.doc.name});
            // });

            // frm.add_custom_button(__('Accounts Receivable'), function() {
            //  frappe.set_route('query-report', 'Accounts Receivable', {member:frm.doc.name});
            // });

            // indicator
            erpnext.utils.set_party_dashboard_indicators(frm);

        } else {
            frappe.contacts.clear_address_and_contact(frm);
        }

        frappe.call({
            method: "frappe.client.get_value",
            args: {
                'doctype': "Membership",
                'filters': { 'member': frm.doc.name },
                'fieldname': [
                    'to_date'
                ]
            },
            callback: function(data) {
                if (data.message) {
                    frappe.model.set_value(frm.doctype, frm.docname,
                        "membership_expiry_date", data.message.to_date);
                }
            }
        });

        // insert in user table

        // if (!frm.doc.__islocal) {
        //     frappe.call({
        //         method: "frappe.client.insert",
        //         args: {
        //             doc: {
        //                 "doctype": "User",
        //                 "email": frm.doc.email,
        //                 "first_name": frm.doc.member_name,
        //                 "send_welcome_email":0
        //             }

        //         },
        //         callback: function(r) {
        //             console.log(r)
        //             if (r) {
        //                 frappe.call({
        //                     method: "erpnext.non_profit.doctype.member.member.add_parentrole",
        //                     args: {
        //                         email: frm.doc.email
        //                     },
        //                     success: function(data) {
        //                         console.log(data)
        //                     }
        //                 });
        //             }
        //         }
        //     });
        // }
    }
    // after_save: function(frm) {
    //     console.log(frm.doc.email);
    //     if (!frm.doc._islocal) {
    //         // var email = []
    //         //  var first_name = []
    //         for (var i = 0; i < frm.doc.table_25.length; i++) {
    //             var email = frm.doc.table_25[i].email;
    //             var first_name = frm.doc.table_25[i].member_name;
    //             console.log(frm.doc.email);
    //             console.log(frm.doc.first_name);
    //             frappe.call({
    //                 method: "frappe.client.insert",
    //                 args: {
    //                     doc: {
    //                         "doctype": "User",
    //                         "email": email,
    //                         "first_name": first_name,
    //                         "send_welcome_email":0
    //                     }

    //                 },
    //                 callback: function(r) {
    //                     console.log(r)
    //                     if (r) {
    //                         frappe.call({
    //                             method: "erpnext.non_profit.doctype.member.member.add_parentrole",
    //                             args: {
    //                                 email: email
    //                             },
    //                             success: function(data) {
    //                                 console.log(data)
    //                             }
    //                         });
    //                     }
    //                 }
    //             });
    //         }
    //     }
    // }
});