frappe.listview_settings['Donor'] = {
	add_fields: ["donor_name", "donor_type", "image"],
};
